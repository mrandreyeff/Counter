//package lv.sergey.activity;



import java.util.ResourceBundle;

public class Counter
{
  public static void main(String[] args)
  {   
    ResourceBundle labels;
    if(args.length()>0)
      labels = ResourceBundle.getBundle(args[0]);
    else
      labels = ResourceBundle.getBundle("zombo");
    String s = labels.getString("message");
    System.out.println(s);
    System.out.println("String's length is "+getLength(s));
  }

  public int getLength(String s){
    return s.length();
  }
}
